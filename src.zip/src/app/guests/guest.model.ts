export interface Guest {
  id: number;
  name: string;
  contactNo: string;
}
